import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Check, Clock, Info } from "lucide-react";
import { Reveal } from "@/components/reveal";
import { getFormation, HORAIRES, type Formation } from "@/lib/formations";

export const Route = createFileRoute("/formations/$slug")({
  loader: ({ params }) => {
    const formation = getFormation(params.slug);
    if (!formation) throw notFound();
    return { formation };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return { meta: [{ title: "Formation introuvable — Atelier Safael" }, { name: "robots", content: "noindex" }] };
    }
    const f = loaderData.formation;
    return {
      meta: [
        { title: `${f.title} — Atelier Safael` },
        { name: "description", content: f.short },
        { property: "og:title", content: `${f.title} — Atelier Safael` },
        { property: "og:description", content: f.short },
        { property: "og:url", content: `/formations/${f.slug}` },
      ],
      links: [{ rel: "canonical", href: `/formations/${f.slug}` }],
    };
  },
  component: FormationDetail,
});

function FormationDetail() {
  const { formation: f } = Route.useLoaderData() as { formation: Formation };

  return (
    <>
      <section className="bg-blush/50 pt-36 pb-16">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <Reveal>
            <Link
              to="/formations"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
            >
              <ArrowLeft className="h-4 w-4" /> Toutes les formations
            </Link>
            <p className="eyebrow mt-8 text-primary">{f.tag}</p>
            <h1 className="mt-4 max-w-3xl font-display text-4xl leading-tight font-semibold sm:text-5xl">
              {f.title}
            </h1>
            {f.prerequis && (
              <p className="mt-5 inline-flex items-center gap-2 rounded-full bg-background px-5 py-2.5 text-sm font-semibold text-primary shadow-soft">
                <Info className="h-4 w-4" /> {f.prerequis}
              </p>
            )}
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr]">
          <Reveal>
            <div>
              <img
                src={f.image}
                alt={f.title}
                width={1200}
                height={900}
                className="w-full rounded-3xl object-cover shadow-soft"
              />
              <p className="mt-8 leading-relaxed text-muted-foreground">{f.intro}</p>

              <h2 className="mt-10 font-display text-3xl font-semibold">Les cours</h2>
              <ul className="mt-5 space-y-3">
                {f.cours.map((c) => (
                  <li key={c} className="flex items-start gap-3 text-sm text-foreground/85">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    {c}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <Reveal delay={120}>
            <div className="space-y-6 lg:sticky lg:top-28">
              {(f.duree || f.prix) && (
                <div className="rounded-3xl border border-border bg-card p-8 shadow-soft">
                  {f.duree && (
                    <>
                      <p className="eyebrow text-primary">Durée</p>
                      <p className="mt-2 font-display text-2xl font-semibold">{f.duree}</p>
                    </>
                  )}
                  {f.prix && (
                    <div className={f.duree ? "mt-6 border-t border-border pt-6" : ""}>
                      <p className="eyebrow text-primary">Prix</p>
                      <div className="mt-2 space-y-1">
                        {f.prix.map((p, i) => (
                          <p
                            key={p}
                            className={
                              i === 0
                                ? "font-display text-3xl font-semibold text-primary"
                                : "text-sm text-muted-foreground"
                            }
                          >
                            {p}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="rounded-3xl bg-blush/60 p-8">
                <span className="flex items-center gap-2 text-primary">
                  <Clock className="h-4 w-4" />
                  <span className="eyebrow">Horaires</span>
                </span>
                <div className="mt-4 space-y-1 text-sm text-foreground/85">
                  {HORAIRES.map((h) => (
                    <p key={h} className="font-medium">
                      {h}
                    </p>
                  ))}
                </div>
              </div>

              <Link
                to="/contact"
                hash="inscription"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-medium text-primary-foreground shadow-rose transition-transform duration-300 hover:-translate-y-1"
              >
                S'inscrire à cette formation <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
