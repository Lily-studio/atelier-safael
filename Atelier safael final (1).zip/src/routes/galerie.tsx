import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Reveal } from "@/components/reveal";
import p1 from "@/assets/photo_safael_tradi_1.jpeg.asset.json";
import p2 from "@/assets/photo_safael_tradi_2.jpeg.asset.json";
import p3 from "@/assets/photo_safael_tradi_3.jpeg.asset.json";
import p4 from "@/assets/phtoto_safael_moderne_1.jpeg.asset.json";
import p5 from "@/assets/photo_safael_moderne_2.jpeg.asset.json";
import p6 from "@/assets/photo_moderne_3.jpeg.asset.json";

export const Route = createFileRoute("/galerie")({
  component: GaleriePage,
  head: () => ({
    meta: [
      { title: "Galerie des créations Atelier Safael" },
      {
        name: "description",
        content:
          "Découvrez en images les créations de l'Atelier Safael : caftans, jellabas, kimonos et pièces modernes réalisées à l'atelier.",
      },
      { property: "og:title", content: "Galerie des créations Atelier Safael" },
      {
        property: "og:description",
        content: "Les créations de l'atelier en images : pièces traditionnelles et modernes.",
      },
      { property: "og:url", content: "/galerie" },
    ],
    links: [{ rel: "canonical", href: "/galerie" }],
  }),
});

const ITEMS = [
  { src: p1.url, alt: "Jellaba lilas à broderies, création Atelier Safael" },
  { src: p2.url, alt: "Gandoura imprimée léopard à sfifa marron" },
  { src: p3.url, alt: "Caftan rose à motifs floraux et sfifa kaki" },
  { src: p4.url, alt: "Kimono moderne à imprimé ethnique" },
  { src: p5.url, alt: "Robe moderne fluide couleur camel" },
  { src: p6.url, alt: "Jupe longue plissée bleu roi" },
];

function GaleriePage() {
  return (
    <>
      <section className="bg-blush/50 pt-36 pb-20">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <Reveal>
            <p className="eyebrow text-primary">Galerie</p>
            <h1 className="mt-5 max-w-3xl font-display text-5xl leading-[1.05] font-semibold sm:text-6xl">
              Galerie des créations
              <span className="block italic text-primary">Atelier Safael</span>
            </h1>
            <p className="mt-6 max-w-xl leading-relaxed text-muted-foreground">
              Des patrons tracés à la main, des toiles épinglées, des rires entre deux
              coutures : voici notre quotidien.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5">
          {ITEMS.map((item, i) => (
            <Reveal key={item.src} delay={(i % 3) * 90}>
              <figure className="group relative overflow-hidden rounded-2xl break-inside-avoid shadow-soft">
                <img
                  src={item.src}
                  alt={item.alt}
                  loading="lazy"
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <figcaption className="absolute inset-x-0 bottom-0 translate-y-full bg-gradient-to-t from-ink/85 to-transparent px-5 py-4 text-sm text-ink-foreground transition-transform duration-500 group-hover:translate-y-0">
                  {item.alt}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-24 sm:px-8">
        <Reveal>
          <div className="rounded-3xl bg-secondary/70 px-8 py-14 text-center sm:px-16">
            <h2 className="font-display text-4xl font-semibold sm:text-5xl">
              Votre création pourrait être la prochaine
            </h2>
            <Link
              to="/contact"
              hash="inscription"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-medium text-primary-foreground shadow-rose transition-transform duration-300 hover:-translate-y-1"
            >
              Je m'inscris <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
