import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Instagram, Mail, MessageCircle, MapPin, Send } from "lucide-react";
import { Reveal } from "@/components/reveal";
import { CONTACT } from "@/components/site-footer";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact & inscription — Atelier Safael" },
      {
        name: "description",
        content:
          "Inscrivez-vous à une formation de l'Atelier Safael à Rabat : formulaire d'inscription envoyé directement sur WhatsApp.",
      },
      { property: "og:title", content: "Contact & inscription — Atelier Safael" },
      {
        property: "og:description",
        content: "Formulaire d'inscription et coordonnées de l'Atelier Safael, Espace Coworking Rabat.",
      },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
});

const FORMATION_OPTIONS = [
  "Coupe Traditionnelle — Niveau 1",
  "Coupe Traditionnelle — Niveau 2",
  "Modélisme Moderne — Niveau 1",
  "Modélisme Moderne — Niveau 2",
] as const;

const HORAIRE_OPTIONS = [
  "En semaine (matin)",
  "En semaine (soir)",
  "Week-end (samedi)",
  "Week-end (dimanche)",
] as const;

const schema = z.object({
  nom: z.string().trim().min(2, "Merci d'indiquer votre nom complet.").max(80),
  telephone: z
    .string()
    .trim()
    .min(8, "Numéro de téléphone trop court.")
    .max(24, "Numéro de téléphone trop long."),
  age: z
    .string()
    .trim()
    .max(3, "Âge invalide.")
    .regex(/^\d*$/, "Âge invalide.")
    .optional(),
  horaire: z.enum(HORAIRE_OPTIONS),
  formation: z.enum(FORMATION_OPTIONS),
  message: z.string().trim().max(800, "Message trop long (800 caractères maximum).").optional(),
});

const EMPTY = {
  nom: "",
  telephone: "",
  age: "",
  horaire: HORAIRE_OPTIONS[0] as string,
  formation: FORMATION_OPTIONS[0] as string,
  message: "",
};

const CHANNELS = [
  { icon: MessageCircle, label: "WhatsApp", value: CONTACT.whatsapp, href: CONTACT.whatsappUrl },
  { icon: Instagram, label: "Instagram", value: CONTACT.instagramHandle, href: CONTACT.instagram },
  { icon: Mail, label: "Email", value: CONTACT.email, href: `mailto:${CONTACT.email}` },
];

function ContactPage() {
  const [values, setValues] = useState(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);

  const update = (key: string, value: string) => {
    setValues((v) => ({ ...v, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(values);
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) next[String(issue.path[0])] = issue.message;
      setErrors(next);
      toast.error("Merci de vérifier les champs indiqués.");
      return;
    }
    setSending(true);
    const d = parsed.data;
    const lines = [
      "Bonjour Atelier Safael !",
      "",
      `Nom complet : ${d.nom}`,
      `Téléphone : ${d.telephone}`,
      ...(d.age ? [`Âge : ${d.age}`] : []),
      `Horaire souhaité : ${d.horaire}`,
      `Formation souhaitée : ${d.formation}`,
      ...(d.message ? [`Message : ${d.message}`] : []),
    ];
    const text = encodeURIComponent(lines.join("\n"));
    window.open(`${CONTACT.whatsappUrl}?text=${text}`, "_blank", "noopener");
    setTimeout(() => {
      setSending(false);
      setValues(EMPTY);
      toast.success("Demande prête ! Envoyez-la sur WhatsApp pour finaliser votre inscription.");
    }, 600);
  };

  const field =
    "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition-colors focus:border-primary focus:ring-2 focus:ring-ring/25";

  return (
    <>
      <section className="bg-blush/50 pt-36 pb-20">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <Reveal>
            <p className="eyebrow text-primary">Contact</p>
            <h1 className="mt-5 max-w-3xl font-display text-5xl leading-[1.05] font-semibold sm:text-6xl">
              Réservez votre place
              <span className="block italic text-primary">à l'atelier</span>
            </h1>
            <p className="mt-6 max-w-xl leading-relaxed text-muted-foreground">
              Remplissez le formulaire ou écrivez-nous directement : nous répondons
              généralement dans la journée.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.25fr_1fr]">
          <Reveal>
            <form
              id="inscription"
              onSubmit={onSubmit}
              noValidate
              className="scroll-mt-28 rounded-3xl border border-border bg-card p-8 shadow-soft sm:p-10"
            >
              <h2 className="font-display text-3xl font-semibold">Formulaire d'inscription</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Tous les champs marqués d'un astérisque sont obligatoires.
              </p>

              <div className="mt-8 grid gap-5 sm:grid-cols-2">
                <div className="sm:col-span-2">
                  <label htmlFor="nom" className="text-sm font-medium">
                    Nom complet *
                  </label>
                  <input
                    id="nom"
                    value={values.nom}
                    onChange={(e) => update("nom", e.target.value)}
                    maxLength={80}
                    className={field}
                    placeholder="Votre nom et prénom"
                  />
                  {errors['nom'] && <p className="mt-1 text-xs text-destructive">{errors['nom']}</p>}
                </div>

                <div>
                  <label htmlFor="age" className="text-sm font-medium">
                    Âge
                  </label>
                  <input
                    id="age"
                    type="text"
                    inputMode="numeric"
                    value={values.age}
                    onChange={(e) => update("age", e.target.value)}
                    maxLength={3}
                    className={field}
                    placeholder="Optionnel"
                  />
                  {errors['age'] && <p className="mt-1 text-xs text-destructive">{errors['age']}</p>}
                </div>

                <div>
                  <label htmlFor="telephone" className="text-sm font-medium">
                    Téléphone *
                  </label>
                  <input
                    id="telephone"
                    type="tel"
                    value={values.telephone}
                    onChange={(e) => update("telephone", e.target.value)}
                    maxLength={24}
                    className={field}
                    placeholder="+212 6 00 00 00 00"
                  />
                  {errors['telephone'] && (
                    <p className="mt-1 text-xs text-destructive">{errors['telephone']}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="horaire" className="text-sm font-medium">
                    Horaire *
                  </label>
                  <select
                    id="horaire"
                    value={values.horaire}
                    onChange={(e) => update("horaire", e.target.value)}
                    className={field}
                  >
                    {HORAIRE_OPTIONS.map((o) => (
                      <option key={o}>{o}</option>
                    ))}
                  </select>
                  {errors['horaire'] && (
                    <p className="mt-1 text-xs text-destructive">{errors['horaire']}</p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="formation" className="text-sm font-medium">
                    Formation souhaitée *
                  </label>
                  <select
                    id="formation"
                    value={values.formation}
                    onChange={(e) => update("formation", e.target.value)}
                    className={field}
                  >
                    {FORMATION_OPTIONS.map((o) => (
                      <option key={o}>{o}</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label htmlFor="message" className="text-sm font-medium">
                    Votre message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    value={values.message}
                    onChange={(e) => update("message", e.target.value)}
                    maxLength={800}
                    className={field}
                    placeholder="Parlez-nous de votre projet, de vos disponibilités…"
                  />
                  {errors['message'] && (
                    <p className="mt-1 text-xs text-destructive">{errors['message']}</p>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={sending}
                className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 text-sm font-medium text-primary-foreground shadow-rose transition-transform duration-300 hover:-translate-y-1 disabled:opacity-70"
              >
                {sending ? "Envoi…" : "Envoyer ma demande"}
                <Send className="h-4 w-4" />
              </button>
            </form>
          </Reveal>

          <Reveal delay={120}>
            <div className="space-y-4">
              {CHANNELS.map((c) => (
                <a
                  key={c.label}
                  href={c.href}
                  target={c.href.startsWith("mailto") ? undefined : "_blank"}
                  rel="noreferrer"
                  className="flex items-center gap-4 rounded-2xl border border-border bg-card p-6 transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-soft"
                >
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-blush text-primary">
                    <c.icon className="h-4 w-4" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-xs tracking-wide text-muted-foreground uppercase">
                      {c.label}
                    </span>
                    <span className="block truncate font-medium">{c.value}</span>
                  </span>
                </a>
              ))}

              <div className="rounded-2xl bg-blush/50 p-6">
                <span className="flex items-center gap-2 text-primary">
                  <MapPin className="h-4 w-4" />
                  <span className="eyebrow">L'atelier</span>
                </span>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  Espace Coworking Rabat
                  <br />
                  Avenue Allal Ben Abdellah
                  <br />
                  En face de l'École Supérieure de Management
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </>
  );
}
