import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Clock } from "lucide-react";
import { Reveal } from "@/components/reveal";
import { FORMATIONS, HORAIRES } from "@/lib/formations";

export const Route = createFileRoute("/formations/")({
  component: FormationsPage,
  head: () => ({
    meta: [
      { title: "Nos formations — Atelier Safael" },
      {
        name: "description",
        content:
          "Quatre formations : Coupe Traditionnelle niveaux 1 et 2, Modélisme Moderne niveaux 1 et 2. Programmes, durée, prix et horaires de l'Atelier Safael.",
      },
      { property: "og:title", content: "Nos formations — Atelier Safael" },
      {
        property: "og:description",
        content: "Coupe traditionnelle marocaine et modélisme moderne, du niveau débutante au niveau avancé.",
      },
      { property: "og:url", content: "/formations" },
    ],
    links: [{ rel: "canonical", href: "/formations" }],
  }),
});

function FormationsPage() {
  return (
    <>
      <section className="bg-blush/50 pt-36 pb-20">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <Reveal>
            <p className="eyebrow text-primary">Nos formations</p>
            <h1 className="mt-5 max-w-3xl font-display text-5xl leading-[1.05] font-semibold sm:text-6xl">
              Apprendre à créer,
              <span className="block italic text-primary">à votre rythme</span>
            </h1>
            <p className="mt-6 max-w-xl leading-relaxed text-muted-foreground">
              Quatre parcours complémentaires, entièrement pratiques, de la coupe
              traditionnelle marocaine au modélisme moderne.
            </p>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 sm:px-8">
        <div className="grid gap-6 sm:grid-cols-2">
          {FORMATIONS.map((f, i) => (
            <Reveal key={f.slug} delay={i * 100}>
              <Link
                to="/formations/$slug"
                params={{ slug: f.slug }}
                className="group flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:border-primary/40 hover:shadow-soft"
              >
                <div className="overflow-hidden">
                  <img
                    src={f.image}
                    alt={f.title}
                    loading="lazy"
                    width={1200}
                    height={900}
                    className="h-56 w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="flex flex-1 flex-col p-8">
                  <p className="eyebrow text-primary">{f.tag}</p>
                  <h2 className="mt-3 font-display text-2xl font-semibold sm:text-3xl">{f.title}</h2>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {f.short}
                  </p>
                  <div className="mt-6 flex items-end justify-between gap-4">
                    {f.prix?.[0] ? (
                      <p className="font-display text-2xl font-semibold text-primary">{f.prix[0]}</p>
                    ) : (
                      <span />
                    )}
                    <span className="link-underline inline-flex items-center gap-2 text-sm font-medium text-primary">
                      Découvrir <ArrowRight className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <div className="mt-10 rounded-3xl bg-blush/50 px-8 py-10 text-center">
            <span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-background text-primary">
              <Clock className="h-5 w-5" />
            </span>
            <h2 className="mt-4 font-display text-2xl font-semibold text-primary">Horaires</h2>
            <div className="mt-4 space-y-1 text-sm text-foreground/85">
              {HORAIRES.map((h) => (
                <p key={h} className="font-medium">
                  {h}
                </p>
              ))}
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
