import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Heart, Quote, Star } from "lucide-react";
import { Reveal } from "@/components/reveal";
import g3 from "@/assets/gallery-3.jpg";
import g5 from "@/assets/gallery-5.jpg";

export const Route = createFileRoute("/notre-histoire")({
  component: HistoirePage,
  head: () => ({
    meta: [
      { title: "Notre histoire — Atelier Safael" },
      {
        name: "description",
        content:
          "Atelier Safael est né d'un rêve : créer un lieu où chaque femme puisse révéler sa créativité et concevoir des vêtements qui lui ressemblent.",
      },
      { property: "og:title", content: "Notre histoire — Atelier Safael" },
      {
        property: "og:description",
        content: "L'histoire de Safae El Haddady et de la naissance de l'Atelier Safael à Rabat.",
      },
      { property: "og:url", content: "/notre-histoire" },
    ],
    links: [{ rel: "canonical", href: "/notre-histoire" }],
  }),
});

const STATS = [
  { value: "+100", label: "élèves formées" },
  { value: "-10", label: "élèves par groupe" },
  { value: "100%", label: "créativité" },
];

const TESTIMONIALS = [
  {
    name: "Salma B.",
    role: "Élève — Modélisme Moderne",
    text: "J'étais débutante complète. En deux mois j'ai réalisé mes premiers patrons et ma première robe. L'ambiance est douce et exigeante à la fois.",
  },
  {
    name: "Imane L.",
    role: "Élève — Coupe Traditionnelle",
    text: "J'ai enfin compris la logique de la coupe traditionnelle. Safae explique avec une clarté rare et beaucoup de patience.",
  },
  {
    name: "Nadia R.",
    role: "Élève — Modélisme Moderne",
    text: "Un vrai atelier : on essaie, on se trompe, on recommence. On repart avec un savoir-faire et beaucoup de confiance.",
  },
];

const RECITS = [
  {
    q: "Depuis quand es-tu passionnée par le modélisme et le stylisme ?",
    a: "Ma passion pour le stylisme est née dès l'âge de 8 ans. J'imaginais et dessinais des silhouettes inspirées par la nature, explorant déjà la création avec curiosité et créativité.",
  },
  {
    q: "Qui t'a donné l'idée de créer cet atelier ?",
    a: "L'idée est née en échangeant avec mon entourage et mes amies, qui exprimaient souvent leur frustration face à la fast fashion, aux styles qui se répètent et à une mode de plus en plus standardisée. Je me suis alors dit qu'il était temps de proposer une alternative : un atelier où chaque femme peut apprendre à créer librement, développer sa créativité et concevoir des vêtements qui reflètent réellement sa personnalité, sans être limitée par les tendances ou les standards.",
  },
  {
    q: "Comment se sont déroulés les préparatifs avant l'ouverture de l'atelier ?",
    a: "Les préparatifs ont commencé plusieurs mois avant l'ouverture de l'atelier. Cette période a été consacrée à la réflexion, à la conception du projet et à la création d'un espace d'apprentissage inspirant. J'ai travaillé sur le programme des formations ainsi que sur l'identité de l'atelier.",
  },
  {
    q: "Aujourd'hui, combien d'élèves ont appris ou se sont formés dans ton atelier ?",
    a: "Plus de 100 élèves.",
  },
];

function HistoirePage() {
  return (
    <>
      <section className="bg-blush/50 pt-36 pb-20">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <Reveal>
            <p className="eyebrow text-primary">Notre histoire</p>
            <h1 className="mt-5 max-w-3xl font-display text-5xl leading-[1.05] font-semibold sm:text-6xl">
              Raconte l'histoire
              <span className="block italic text-primary">de ton atelier</span>
            </h1>
          </Reveal>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 sm:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-2">
          <Reveal>
            <img
              src={g3}
              alt="Mannequin de couture avec un drapé épinglé"
              loading="lazy"
              width={900}
              height={1300}
              className="w-full rounded-2xl object-cover shadow-soft"
            />
          </Reveal>
          <Reveal delay={120}>
            <div>
              <p className="leading-relaxed text-muted-foreground">
                Atelier Safael est né d'un rêve : celui de créer un lieu où chaque femme
                puisse révéler sa créativité, exprimer sa personnalité et reprendre le
                plaisir de créer de ses propres mains. Dans un monde où la mode devient
                souvent uniforme, j'ai souhaité offrir bien plus qu'une simple formation :
                un espace chaleureux où l'on apprend, où l'on partage, où l'on ose créer
                et où chacune découvre le bonheur de concevoir des vêtements qui lui
                ressemblent. Voir mes élèves gagner en confiance, développer leur
                savoir-faire et être fières de leurs créations est aujourd'hui ma plus
                belle motivation.
              </p>
              <p className="mt-8 font-display text-2xl text-primary italic">
                Safae El Haddady
              </p>
              <p className="text-xs tracking-wide text-muted-foreground uppercase">
                Fondatrice & formatrice
              </p>
            </div>
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary/60 py-24">
        <div className="mx-auto max-w-4xl px-5 sm:px-8">
          <Reveal>
            <h2 className="text-center font-display text-4xl font-semibold sm:text-5xl">
              Le fil de la passion
            </h2>
          </Reveal>

          <ol className="relative mt-14 space-y-10 border-l border-rose/60 pl-8">
            {RECITS.map((t, i) => (
              <Reveal key={t.q} delay={i * 90}>
                <li className="relative">
                  <span className="absolute top-1.5 -left-[41px] grid h-5 w-5 place-items-center rounded-full bg-primary">
                    <Heart className="h-2.5 w-2.5 text-primary-foreground" />
                  </span>
                  <h3 className="font-display text-2xl leading-snug font-semibold">{t.q}</h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t.a}</p>
                </li>
              </Reveal>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-5 py-24 sm:px-8">
        <Reveal>
          <p className="eyebrow text-center text-primary">L'origine de ma passion</p>
          <h2 className="mt-4 text-center font-display text-4xl font-semibold sm:text-5xl">
            Depuis mon enfance
          </h2>
          <p className="mt-8 text-center leading-relaxed text-muted-foreground">
            Depuis mon enfance, les tissus, les couleurs et la création m'ont toujours
            fascinée. Très jeune, je passais des heures à imaginer des vêtements et à
            rêver de donner vie à mes propres idées. Avec le temps, cette passion n'a
            cessé de grandir et s'est enrichie grâce à des études supérieures ainsi qu'à
            des formations professionnelles. Aujourd'hui, transmettre cette passion et
            voir d'autres femmes découvrir leur potentiel est ce qui me rend le plus
            heureuse.
          </p>
        </Reveal>
      </section>

      {/* STATS */}
      <section className="border-y border-border bg-blush/40">
        <div className="mx-auto grid max-w-6xl grid-cols-2 gap-8 px-5 py-12 sm:px-8 md:grid-cols-4">
          {STATS.map((s, i) => (
            <Reveal key={s.label} delay={i * 90}>
              <div className="text-center">
                <p className="font-display text-4xl font-semibold text-primary">{s.value}</p>
                <p className="mt-1 text-xs tracking-wide text-muted-foreground uppercase">
                  {s.label}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* INFOS GÉNÉRALES */}
      <section className="mx-auto max-w-6xl px-5 py-24 sm:px-8">
        <Reveal>
          <p className="eyebrow text-primary">Informations générales</p>
          <h2 className="mt-4 max-w-2xl font-display text-4xl font-semibold sm:text-5xl">
            L'essentiel à savoir
          </h2>
        </Reveal>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {[
            {
              q: "Les formations sont-elles 100 % pratiques ?",
              a: "Oui, nos formations sont entièrement pratiques afin de permettre un apprentissage concret et efficace.",
            },
            {
              q: "Combien d'élèves ont suivi tes formations depuis le début de ton activité ?",
              a: "Plus de 100 élèves.",
            },
            { q: "Combien d'élèves y a-t-il en moyenne par groupe ?", a: "Moins de 10 personnes." },
          ].map((item, i) => (
            <Reveal key={item.q} delay={i * 90}>
              <div className="h-full rounded-2xl border border-border bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:shadow-soft">
                <p className="text-sm leading-relaxed text-muted-foreground">{item.q}</p>
                <p className="mt-3 font-display text-2xl font-semibold text-primary">{item.a}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* TÉMOIGNAGES */}
      <section className="bg-blush/50 py-24">
        <div className="mx-auto max-w-6xl px-5 sm:px-8">
          <Reveal>
            <p className="eyebrow text-center text-primary">Elles en parlent</p>
            <h2 className="mx-auto mt-4 max-w-2xl text-center font-display text-4xl font-semibold sm:text-5xl">
              Les mots de nos élèves
            </h2>
          </Reveal>
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {TESTIMONIALS.map((t, i) => (
              <Reveal key={t.name} delay={i * 110}>
                <figure className="flex h-full flex-col rounded-2xl bg-background p-8 shadow-soft">
                  <Quote className="h-6 w-6 text-rose" />
                  <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-muted-foreground italic">
                    « {t.text} »
                  </blockquote>
                  <div className="mt-6 flex gap-0.5 text-primary">
                    {Array.from({ length: 5 }).map((_, k) => (
                      <Star key={k} className="h-3.5 w-3.5 fill-current" />
                    ))}
                  </div>
                  <figcaption className="mt-3">
                    <p className="font-display text-lg font-semibold">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </figcaption>
                </figure>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-24 sm:px-8">
        <div className="grid items-center gap-12 overflow-hidden rounded-3xl bg-blush/50 lg:grid-cols-2">
          <img
            src={g5}
            alt="Groupe d'élèves en atelier"
            loading="lazy"
            width={1200}
            height={1000}
            className="h-full w-full object-cover"
          />
          <div className="px-8 py-12 sm:px-12">
            <h2 className="font-display text-4xl font-semibold sm:text-5xl">
              Venez écrire la suite avec nous
            </h2>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Les groupes sont volontairement réduits : moins de 10 personnes par session,
              pour apprendre dans une ambiance chaleureuse.
            </p>
            <Link
              to="/contact"
              hash="inscription"
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-medium text-primary-foreground shadow-rose transition-transform duration-300 hover:-translate-y-1"
            >
              Rejoindre l'atelier <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
