import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart, ArrowRight } from "lucide-react";
import { Reveal } from "@/components/reveal";
import { FORMATIONS, HORAIRES } from "@/lib/formations";
import heroImg from "@/assets/hero-atelier.jpg";

export const Route = createFileRoute("/")({
  component: HomePage,
  head: () => ({
    meta: [
      { title: "Atelier Safael — Formations de modélisme et coupe à Rabat" },
      {
        name: "description",
        content:
          "Atelier Safael, fondé par Safae El Haddady : formations de coupe traditionnelle marocaine et de modélisme moderne à Rabat, en petits groupes.",
      },
      { property: "og:title", content: "Atelier Safael — Formations de modélisme et coupe à Rabat" },
      {
        property: "og:description",
        content:
          "Un lieu où la créativité reprend sa place et où chaque femme découvre qu'elle est capable de créer.",
      },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
});

function HomePage() {
  return (
    <>
      {/* HERO */}
      <section className="relative flex min-h-[92vh] items-center overflow-hidden">
        <img
          src={heroImg}
          alt="Atelier Safael, mannequin de couture et tissus"
          width={1600}
          height={1100}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/96 via-background/85 to-background/30" />
        <div className="absolute -right-24 top-24 hidden h-72 w-72 rounded-full bg-rose/40 blur-3xl md:block" />

        <div className="relative mx-auto w-full max-w-6xl px-5 pt-32 pb-20 sm:px-8">
          <Reveal delay={100}>
            <h1 className="mt-5 max-w-3xl font-display text-3xl leading-[1.15] font-semibold text-foreground sm:text-4xl lg:text-5xl">
              Parce que chaque femme mérite de créer librement.
            </h1>
          </Reveal>
          <Reveal delay={200}>
            <div className="mt-8 max-w-2xl text-base leading-relaxed text-muted-foreground">
              <p>
                Chez Atelier Safael, vous trouverez bien plus qu'une formation : une
                communauté, un accompagnement personnalisé et un espace où vos idées
                prennent vie.
              </p>
            </div>
          </Reveal>
          <Reveal delay={300}>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                to="/contact"
                hash="inscription"
                className="group inline-flex items-center gap-2 rounded-full bg-primary px-7 py-4 text-sm font-medium text-primary-foreground shadow-rose transition-transform duration-300 hover:-translate-y-1"
              >
                Je m'inscris
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
              <Link
                to="/formations"
                className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-background/70 px-7 py-4 text-sm font-medium text-primary backdrop-blur transition-colors hover:bg-blush/60"
              >
                Voir les formations
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FORMATIONS */}
      <section className="mx-auto max-w-6xl px-5 py-24 sm:px-8">
        <Reveal>
          <p className="eyebrow text-primary">Nos formations</p>
          <h2 className="mt-4 max-w-2xl font-display text-4xl font-semibold sm:text-5xl">
            Choisissez la formation qui vous inspire
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-6 sm:grid-cols-2">
          {FORMATIONS.map((f, i) => (
            <Reveal key={f.slug} delay={i * 100}>
              <Link
                to="/formations/$slug"
                params={{ slug: f.slug }}
                className="group flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-card transition-all duration-500 hover:-translate-y-2 hover:border-primary/40 hover:shadow-soft"
              >
                <div className="overflow-hidden">
                  <img
                    src={f.image}
                    alt={f.title}
                    loading="lazy"
                    width={1200}
                    height={900}
                    className="h-52 w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="flex flex-1 flex-col p-8">
                  <p className="eyebrow text-primary">{f.tag}</p>
                  <h3 className="mt-3 font-display text-2xl font-semibold sm:text-3xl">
                    {f.title}
                  </h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
                    {f.short}
                  </p>
                  <span className="link-underline mt-6 inline-flex items-center gap-2 text-sm font-medium text-primary">
                    Découvrir la formation <ArrowRight className="h-4 w-4" />
                  </span>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <div className="mt-10 rounded-3xl bg-blush/50 px-8 py-10 text-center">
            <h3 className="font-display text-2xl font-semibold text-primary">Horaires</h3>
            <div className="mt-4 space-y-1 text-sm text-foreground/85">
              {HORAIRES.map((h) => (
                <p key={h} className="font-medium">
                  {h}
                </p>
              ))}
            </div>
          </div>
        </Reveal>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-5 py-24 sm:px-8">
        <Reveal>
          <div className="gradient-rose relative overflow-hidden rounded-3xl px-8 py-16 text-center sm:px-16">
            <Heart className="heartbeat mx-auto h-6 w-6 text-primary-foreground/85" />
            <h2 className="mt-5 font-display text-4xl font-semibold text-primary-foreground sm:text-5xl">
              Prête à révéler votre créativité ?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-primary-foreground/85">
              Parce que chaque parcours est unique, nous limitons chaque groupe à moins
              de 10 participantes pour garantir un suivi personnalisé, des conseils
              adaptés et une expérience d'apprentissage de qualité.
            </p>
            <Link
              to="/contact"
              hash="inscription"
              className="mt-9 inline-flex items-center gap-2 rounded-full bg-background px-8 py-4 text-sm font-medium text-primary transition-transform duration-300 hover:-translate-y-1"
            >
              Réserver ma place <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
