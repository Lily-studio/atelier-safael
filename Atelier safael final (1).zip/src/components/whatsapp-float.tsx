import { MessageCircle } from "lucide-react";
import { CONTACT } from "@/components/site-footer";

export function WhatsAppFloat() {
  return (
    <a
      href={CONTACT.whatsappUrl}
      target="_blank"
      rel="noreferrer"
      aria-label="Contactez-nous sur WhatsApp"
      className="group fixed right-3 bottom-3 z-50 flex max-w-[80vw] items-center gap-3 rounded-full bg-primary py-2.5 pr-5 pl-2.5 text-primary-foreground shadow-rose transition-all duration-300 hover:-translate-y-1 hover:brightness-110 sm:right-6 sm:bottom-6"
    >
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-primary-foreground/15">
        <MessageCircle className="h-5 w-5" />
      </span>
      <span className="text-xs leading-snug font-medium sm:text-sm">
        💬 Vous avez des questions ? Contactez-nous{" "}
        <span className="heartbeat inline-block">❤️</span>
      </span>
    </a>
  );
}
