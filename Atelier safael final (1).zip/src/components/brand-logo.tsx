import wordmark from "@/assets/safael-wordmark.png.asset.json";
import heart from "@/assets/safael-heart.png.asset.json";

/**
 * Composite SAFAEL logo: static script wordmark with the heart
 * positioned exactly as in the original artwork, beating gently.
 */
export function BrandLogo({ className = "" }: { className?: string }) {
  return (
    <span className={`relative inline-block ${className}`} aria-label="atelier Safael">
      <img
        src={wordmark.url}
        alt="atelier Safael"
        width={1080}
        height={388}
        className="block h-full w-auto"
      />
      <img
        src={heart.url}
        alt=""
        aria-hidden="true"
        className="heartbeat absolute"
        style={{
          left: "51.85%",
          top: "-5.67%",
          width: "19.44%",
          height: "49.23%",
        }}
      />
    </span>
  );
}
