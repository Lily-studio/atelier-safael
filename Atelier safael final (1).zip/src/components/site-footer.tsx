import { Link } from "@tanstack/react-router";
import { Instagram, Mail, MessageCircle, MapPin } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";

export const CONTACT = {
  whatsapp: "+212 617-200562",
  whatsappUrl: "https://wa.me/212617200562",
  instagram: "https://instagram.com/atelier.safael",
  instagramHandle: "@atelier.safael",
  email: "safaeelhaddady1@gmail.com",
  address: ["Espace Coworking Rabat", "Avenue Allal Ben Abdellah", "En face de l'École Supérieure de Management"],
} as const;

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-blush/40">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:px-8 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <BrandLogo className="h-14" />
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted-foreground">
            Atelier de modélisme et de couture. Nous transmettons l'art du patron,
            de la coupe et du geste juste, avec passion et bienveillance.
          </p>
          <div className="mt-6 flex gap-3">
            <a
              href={CONTACT.instagram}
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
              className="grid h-10 w-10 place-items-center rounded-full bg-background text-primary shadow-soft transition-transform duration-300 hover:-translate-y-1"
            >
              <Instagram className="h-4 w-4" />
            </a>
            <a
              href={CONTACT.whatsappUrl}
              target="_blank"
              rel="noreferrer"
              aria-label="WhatsApp"
              className="grid h-10 w-10 place-items-center rounded-full bg-background text-primary shadow-soft transition-transform duration-300 hover:-translate-y-1"
            >
              <MessageCircle className="h-4 w-4" />
            </a>
            <a
              href={`mailto:${CONTACT.email}`}
              aria-label="Email"
              className="grid h-10 w-10 place-items-center rounded-full bg-background text-primary shadow-soft transition-transform duration-300 hover:-translate-y-1"
            >
              <Mail className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div>
          <h3 className="eyebrow text-primary">Navigation</h3>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            {[
              { to: "/", label: "Accueil" },
              { to: "/notre-histoire", label: "Notre histoire" },
              { to: "/formations", label: "Formations" },
              { to: "/galerie", label: "Galerie" },
              { to: "/contact", label: "Contact" },
            ].map((l) => (
              <li key={l.to}>
                <Link to={l.to} className="transition-colors hover:text-primary">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="eyebrow text-primary">Contact</h3>
          <ul className="mt-5 space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <MessageCircle className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <a href={CONTACT.whatsappUrl} target="_blank" rel="noreferrer" className="hover:text-primary">
                {CONTACT.whatsapp}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <Instagram className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <a href={CONTACT.instagram} target="_blank" rel="noreferrer" className="hover:text-primary">
                {CONTACT.instagramHandle}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <a href={`mailto:${CONTACT.email}`} className="hover:text-primary">
                {CONTACT.email}
              </a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span>
                {CONTACT.address.map((line) => (
                  <span key={line} className="block">
                    {line}
                  </span>
                ))}
              </span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-border/70 px-5 py-6 text-center text-xs text-muted-foreground sm:px-8">
        © {new Date().getFullYear()} atelier Safael — Fait avec passion.
      </div>
    </footer>
  );
}
