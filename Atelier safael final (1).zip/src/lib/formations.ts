import trad1 from "@/assets/formation-trad-1.jpg";
import trad2 from "@/assets/formation-trad-2.jpg";
import mod1 from "@/assets/formation-mod-1.jpg";
import mod2 from "@/assets/formation-mod-2.jpg";

export const HORAIRES = [
  "En semaine : matin ou soir",
  "Week-end : samedi ou dimanche",
  "Les horaires seront définis selon les disponibilités.",
];


export type Formation = {
  slug: string;
  tag: string;
  title: string;
  short: string;
  image: string;
  prerequis?: string;
  intro: string;
  cours: string[];
  duree?: string;
  prix?: string[];
};

export const FORMATIONS: Formation[] = [
  {
    slug: "coupe-traditionnelle-niveau-1",
    tag: "Coupe Traditionnelle",
    title: "Coupe Traditionnelle — Niveau 1",
    short:
      "Les bases de la coupe traditionnelle marocaine, pas à pas, pour créer des modèles authentiques et élégants.",
    image: trad1,
    intro:
      "Le niveau 1 est destiné aux passionnées de la coupe traditionnelle marocaine qui souhaitent apprendre les bases ou lancer leur propre activité. Vous découvrirez, pas à pas, les techniques de la coupe traditionnelle, le choix de la sfifa, des âakads..., afin de créer des modèles authentiques et élégants.",
    cours: [
      "Gandoura Beldia",
      "Gandoura Beldia modernisée",
      "Jellaba Mkhzania",
      "Caftan Mkhzani",
      "Jellaba épaule normale",
      "Caftan moderne",
      "Kimono",
    ],
    duree: "1 mois (4 h par semaine)",
    prix: ["1200 DH"],
  },

  {
    slug: "coupe-traditionnelle-niveau-2",
    tag: "Coupe Traditionnelle",
    title: "Coupe Traditionnelle — Niveau 2",
    short:
      "Approfondissez votre maîtrise : modèles plus élaborés et touches modernes, sans perdre l'authenticité.",
    image: trad2,
    prerequis: "Passage par le niveau 1 obligatoire.",
    intro:
      "Le niveau 2 est destiné aux participantes ayant validé le niveau 1 et souhaitant approfondir leur maîtrise de la coupe traditionnelle. Vous apprendrez à réaliser des modèles plus élaborés, à perfectionner vos techniques et à intégrer des touches modernes tout en préservant l'élégance et l'authenticité du savoir-faire marocain.",
    cours: [
      "Jellaba avec خراط",
      "Caftan avec خراط",
      "Jellaba emmanchure carrée",
      "Caftan emmanchure carrée",
      "Tekchita",
      "Pantalon élastique",
      "Types de manches et cols",
    ],
    duree: "2 mois (4 h par semaine)",
    prix: [
      "1300 DH par mois",
      "ou",
      "2400 DH si le paiement est effectué en une seule fois.",
    ],
  },
  {
    slug: "modelisme-moderne-niveau-1",
    tag: "Coupe Moderne",
    title: "Coupe Moderne — Niveau 1",
    short:
      "Apprendre le modélisme depuis zéro : patrons et coupe de vêtements du quotidien, casual et intemporels.",
    image: mod1,
    intro:
      "Le Niveau 1 est conçu pour les débutantes qui souhaitent apprendre le modélisme depuis zéro, sans aucune expérience. Vous apprendrez à réaliser les patrons et la coupe de vêtements du quotidien : des modèles casual, modestes et intemporels. À la fin de ce niveau, vous serez capable de modifier et de personnaliser vos patrons selon votre propre style.",
    cours: [
      "Patron de base",
      "Jupe cloche",
      "Pantalon élastique à la taille (droit, ballon, short, jogging)",
      "Hauts (sans manches, bretelles et avec manches)",
      "Robe droite, évasée et avec plis",
      "Chemise",
      "Types de manches et cols",
    ],
    duree: "2 mois (4 h par semaine)",
    prix: [
      "1200 DH/mois",

      "ou",
      "2200 DH au lieu de 2400 DH si les deux mois sont réglés en une seule fois.",
    ],
  },
  {
    slug: "modelisme-moderne-niveau-2",
    tag: "Coupe Moderne",
    title: "Coupe Moderne — Niveau 2",
    short:
      "Patrons techniques et pièces structurées : manteaux, vestes et secrets de conception des marques.",
    image: mod2,
    prerequis: "Passage par le Niveau 1 obligatoire.",
    intro:
      "Le Niveau 2 est destiné aux participantes ayant validé le Niveau 1 et souhaitant approfondir leurs compétences en modélisme. Vous apprendrez à réaliser des patrons plus techniques et des pièces plus élaborées, telles que les manteaux, vestes et vêtements structurés. Ce niveau vous permettra également de découvrir les méthodes et les secrets de conception utilisés dans l'univers des marques de mode.",
    cours: [
      "Corsage avec pinces",
      "Tailleur veste et pantalon",
      "Pantalon classique (plusieurs modèles)",
      "Col châle",
      "Gilet",
      "Trench",
      "Les découpes (bretelles, princesses et passage des pinces)",
    ],
    duree: "2 mois",
    prix: [
      "1300 DH par mois",
      "ou",
      "2400 DH si le paiement est effectué en une seule fois.",
    ],
  },
];

export const getFormation = (slug: string) => FORMATIONS.find((f) => f.slug === slug);
